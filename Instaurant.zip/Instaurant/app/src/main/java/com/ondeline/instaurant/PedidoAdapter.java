package com.ondeline.instaurant;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class PedidoAdapter extends RecyclerView.Adapter<PedidoAdapter.PedidoViewHolder>{

    ArrayList<ItemPedido> pedidos;
    Context context;

    public PedidoAdapter(ArrayList<ItemPedido> pedidos, Context context) {
        this.pedidos = pedidos;
        this.context = context;
    }

    @NonNull
    @Override
    public PedidoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.lista_pedidos_item, viewGroup, false);

        PedidoViewHolder holder = new PedidoViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PedidoViewHolder pedidoViewHolder, int i) {
        pedidoViewHolder.mesa.setText(pedidos.get(i).getMesa());
        pedidoViewHolder.mesa.setBackgroundColor(0x00BBBBBB);
        pedidoViewHolder.cliente.setText(pedidos.get(i).getCliente());
    }

    @Override
    public int getItemCount() {
        return pedidos.size();
    }

    static class PedidoViewHolder extends RecyclerView.ViewHolder {
        TextView mesa;
        TextView cliente;

        public PedidoViewHolder(View itemView) {
            super(itemView);
            this.mesa = itemView.findViewById(R.id.mesa);
            this.cliente = itemView.findViewById(R.id.txtCliente);
        }
    }
}
