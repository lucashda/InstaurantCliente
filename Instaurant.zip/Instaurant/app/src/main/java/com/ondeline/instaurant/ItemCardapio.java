package com.ondeline.instaurant;


import android.net.Uri;
import android.widget.ImageView;

import java.util.Map;

public class ItemCardapio {

    private String nomeItem;
    private String urlImagem;
    private String descricao;
    private String categoria;
    private String valorItem;

    public ItemCardapio(String nome, String url, String valor) {
        this.nomeItem = nome;
        this.urlImagem = url;
        this.valorItem = valor;
    }

    public ItemCardapio(String nomeItem, String urlImagem, String descricao, String categoria, String valorItem) {
        this.nomeItem = nomeItem;
        this.urlImagem = urlImagem;
        this.descricao = descricao;
        this.categoria = categoria;
        this.valorItem = valorItem;
    }

    public String getNomeItem() {
        return nomeItem;
    }

    public String getUrlImagemItem() {
        return urlImagem;
    }

    public String getValorItem() {
        return valorItem;
    }

    public String getDescricaoItem() {
        return descricao;
    }

    public String getCategoriaItem() {
        return categoria;
    }
}
