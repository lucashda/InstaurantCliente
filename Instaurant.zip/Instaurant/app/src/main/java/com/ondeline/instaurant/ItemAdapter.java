package com.ondeline.instaurant;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.util.ArrayList;


public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    ArrayList<String> nomes;
    ArrayList<String> valores;
    ArrayList<String> urls;
    ArrayList<File> paths;

    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
    StorageReference httpsReference;

    File localFile;

    private Context context;

    public ItemAdapter(ArrayList<String> nomes, ArrayList<String> valores, ArrayList<String> urls, Context context) {
        this.nomes = nomes;
        this.valores = valores;
        this.urls = urls;
        this.context = context;
        this.paths = new ArrayList<>();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_view_item, parent, false);

        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        getImageStorage(urls.get(position), holder, position);
        holder.nomeView.setText(nomes.get(position));
        holder.valorView.setText("R$" + valores.get(position));

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "testClick" + position, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return nomes.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView nomeView;
        ImageView imagemView;
        TextView valorView;
        CardView cardView;


        public ViewHolder(View itemView) {
            super(itemView);
            nomeView = itemView.findViewById(R.id.txtNomeItem);
            valorView = itemView.findViewById(R.id.txtValorItem);
            imagemView = itemView.findViewById(R.id.imgItem);
            cardView  = itemView.findViewById(R.id.cardView);
        }
    }

    private void getImageStorage(String url, final ViewHolder holder, final int position){
        httpsReference = firebaseStorage.getReferenceFromUrl(url);
        localFile = null;
        try {
            localFile = File.createTempFile("images", ".JPEG");
            paths.add(localFile);

        } catch (IOException e) {
            e.printStackTrace();
        }
        httpsReference.getFile(paths.get(position))
                .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                holder.imagemView.setImageBitmap(BitmapFactory.decodeFile(paths.get(position).getAbsolutePath()));
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {

            }
        });
    }
}
