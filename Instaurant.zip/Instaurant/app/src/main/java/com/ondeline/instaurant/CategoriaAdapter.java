package com.ondeline.instaurant;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CategoriaAdapter extends ArrayAdapter<String> {
    public CategoriaAdapter(Context context, ArrayList<String> categoriaList) {
        super(context, 0, categoriaList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if(convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.spinner_categoria_item, parent, false
            );
        }

        TextView nomeCategoria = convertView.findViewById(R.id.categoriaItem);

        String currentItem = getItem(position);

        if(currentItem != null) {
            nomeCategoria.setText(currentItem);
        }

        return convertView;
    }
}
