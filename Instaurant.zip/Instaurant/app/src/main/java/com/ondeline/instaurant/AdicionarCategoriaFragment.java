package com.ondeline.instaurant;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link adicionarCategoriasFragmentListener} interface
 * to handle interaction events.
 * Use the {@link AdicionarCategoriaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AdicionarCategoriaFragment extends Fragment {

    FirebaseFirestore db;

    private EditText editText;

    private adicionarCategoriasFragmentListener mListener;

    public AdicionarCategoriaFragment() {
        // Required empty public constructor
    }


    public static AdicionarCategoriaFragment newInstance(String param1, String param2) {
        AdicionarCategoriaFragment fragment = new AdicionarCategoriaFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = FirebaseFirestore.getInstance();
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_adicionar_categoria, container, false);

        editText = view.findViewById(R.id.edtAdicionarCategoria);

        Button cancelar = view.findViewById(R.id.btnCancelarAdicionar);
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.closeAdicionarCategoriasFragment();
            }
        });

        Button adicionar = view.findViewById(R.id.btnConfirmarAdicionar);
        adicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = editText.getText().toString();
                if(!input.equals("")) {
                    setDatabase(input);
                    mListener.closeAdicionarCategoriasFragment();
                } else {
                    Toast.makeText(getActivity().getApplicationContext(), "Campo não pode estar vazio", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof adicionarCategoriasFragmentListener) {
            mListener = (adicionarCategoriasFragmentListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement adicionarCategoriasFragmentListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private void setDatabase(final String input){
        Map<String, Object> map = new HashMap<>();
        map.put("nomeCategoria", input);
        db.collection("Categorias")
                .add(map)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(getActivity().getApplicationContext(), "Categoria \"" + input + "\" adicionada", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public interface adicionarCategoriasFragmentListener {
        // TODO: Update argument type and name
        void closeAdicionarCategoriasFragment();
        void adicionarCategoria(String input);
    }
}
