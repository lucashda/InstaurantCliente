package com.ondeline.instaurant;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class FragmentCardapio extends Fragment {

    private CardapioListener mListener;

    ArrayList<String> nomes;
    ArrayList<String> descricoes;
    ArrayList<String> urls;
    ArrayList<String> categorias;
    ArrayList<String> valores;

    String categoria;

    TextView txtCategoria;

    ItemAdapter adapter;

    public FragmentCardapio() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static FragmentCardapio newInstance(ArrayList<String> nomes, ArrayList<String> descricoes, ArrayList<String> urls, ArrayList<String> categorias, ArrayList<String> valores) {
        FragmentCardapio fragment = new FragmentCardapio();
        Bundle args = new Bundle();

        args.putStringArrayList("nomes", nomes);
        args.putStringArrayList("valores", valores);
        args.putStringArrayList("urls", urls);
        args.putStringArrayList("categorias", categorias);
        args.putStringArrayList("desccricoes", descricoes);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.nomes = new ArrayList<>();
            this.urls = new ArrayList<>();
            this.descricoes = new ArrayList<>();
            this.categorias = new ArrayList<>();
            this.valores = new ArrayList<>();

            getArguments().getStringArrayList("nomes");
            getArguments().getStringArrayList("urls");
            getArguments().getStringArrayList("descricoes");
            getArguments().getStringArrayList("categorias");
            getArguments().getStringArrayList("valores");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fragment_cardapio, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.listaCardapio);
        adapter = new ItemAdapter(nomes, valores, urls, getActivity().getApplicationContext());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity().getApplicationContext()));
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof CardapioListener) {
            mListener = (CardapioListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement CardapioListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface CardapioListener {
        void isRecyclerViewItemClicked(boolean click);
    }
}
