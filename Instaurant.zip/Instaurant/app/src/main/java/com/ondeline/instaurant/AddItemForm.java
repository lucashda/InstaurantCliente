package com.ondeline.instaurant;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ScheduledExecutorService;

public class AddItemForm extends AppCompatActivity
    implements AdicionarCategoriaFragment.adicionarCategoriasFragmentListener{

    private ArrayList<String> categorias;
    private CategoriaAdapter  adapter;
    private Spinner spinnerCategoria;
    private View view;
    private EditText edtNome;
    private EditText edtDescricao;
    private EditText edtValor;
    private ImageView imagem;
    private Bitmap imagemGaleria;

    private FirebaseStorage firebaseStorage;
    private FirebaseAuth firebaseAuth;
    private StorageReference storageReference;
    FirebaseFirestore db;

    private final int GALERIA = 1;
    private final  int PERMISSAO_REQUEST = 2;
    private Uri url;
    private String categoriaItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item_form);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        db = FirebaseFirestore.getInstance();

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) !=
                PackageManager.PERMISSION_GRANTED) {
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSAO_REQUEST);
            }
        }

        //definindo id dos componentes da activity
        edtNome = findViewById(R.id.edtNome);
        edtDescricao = findViewById(R.id.edtDescricao);
        edtValor = findViewById(R.id.edtValor);
        imagem = findViewById(R.id.imagemItem);
        view = findViewById(R.id.containerCategorias);

        view.setVisibility(View.GONE);

        imagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent escolherImagem = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(escolherImagem, GALERIA);
            }
        });

        categorias = new ArrayList<>();
        getCategorias();
        spinnerCategoria = findViewById(R.id.spinnerCategorias);
        adapter = new CategoriaAdapter(this, categorias);
        spinnerCategoria.setAdapter(adapter);

        spinnerCategoria.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                categoriaItem = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        final Button opcaoCategoria = findViewById(R.id.opcaoCategoria);
        opcaoCategoria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.setVisibility(View.VISIBLE);

                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frameCategorias, new AdicionarCategoriaFragment())
                        .commit();
            }
        });

    //Este é o botão de adicionar Item ao Cardápio

        Button adicionar = findViewById(R.id.btnAdicionar);
        adicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setImageStorage();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(data != null) {
            Uri uri = data.getData();
            String[] filePath = {MediaStore.Images.Media.DATA};
            Cursor c = getContentResolver().query(uri, filePath, null, null, null);
            c.moveToFirst();
            int colummIndex = c.getColumnIndex(filePath[0]);
            String picturePath = c.getString(colummIndex);
            c.close();
            imagemGaleria = Bitmap.createScaledBitmap(BitmapFactory.decodeFile(picturePath), 500, 500, true);
            imagem.setImageBitmap(imagemGaleria);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //"gs://" + firebaseAuth.getUid());
        } else {

        }

        return ;
    }

    @Override
    public void closeAdicionarCategoriasFragment() {
            view.setVisibility(View.GONE);
    }

    @Override
    public void adicionarCategoria(String input){
        categorias.add(input);
        adapter = new CategoriaAdapter(this, categorias);
        spinnerCategoria.setAdapter(adapter);
    }

    private void getCategorias(){
        db.collection("Categorias")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        ArrayList<String> strings = new ArrayList<>();
                        for(DocumentSnapshot querySnapshot : task.getResult()) {
                            strings.add(querySnapshot.getString("nomeCategoria"));
                        }
                        setCategorias(strings);
                    }
                });
    }

    public void setCategorias(ArrayList<String> categoriasList){
        this.categorias = categoriasList;
    }

    private void setDatabase(){

        String nome = edtNome.getText().toString();
        String descricao = edtDescricao.getText().toString();
        String valor = edtValor.getText().toString();

        Map<String, Object> item = new HashMap<>();

        ItemCardapio itemCardapio = new ItemCardapio(nome, url.toString(), descricao, categoriaItem, valor);

        item.put("imagem", itemCardapio.getUrlImagemItem());
        item.put("nomeItem", itemCardapio.getNomeItem());
        item.put("categoria", itemCardapio.getCategoriaItem());
        item.put("descricaoItem", itemCardapio.getDescricaoItem());
        item.put("valorItem", itemCardapio.getValorItem());
        //item.put("userId", firebaseAuth.getUid());

        db.collection("Itens")
                .add(item)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Intent intent = new Intent(AddItemForm.this, MainActivity.class);
                        startActivity(intent);
                        Log.d("Successo", "Item adicionado com o ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("Falha", "Erro ao adicionar item à base de dados.", e);
                    }
                });
    }

    private void setImageStorage (){

        storageReference = firebaseStorage.getReference("/storageReference" + UUID.randomUUID() + ".JPEG");
        imagem.setDrawingCacheEnabled(true);
        imagem.buildDrawingCache();
        Bitmap bitmap = ((BitmapDrawable) imagem.getDrawable()).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        UploadTask uploadTask = storageReference.putBytes(data);
        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if(task.isSuccessful()){
                    Log.i("TAG", "Task is successful");
                    return storageReference.getDownloadUrl();
                } else {
                    throw task.getException();
                }
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                url = task.getResult();
                setDatabase();
            }
        });


    }
}
