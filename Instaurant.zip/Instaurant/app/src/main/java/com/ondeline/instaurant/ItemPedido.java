package com.ondeline.instaurant;

public class ItemPedido {
    String mesa;
    String cliente;

    public ItemPedido(String mesa, String cliente) {
        this.mesa = mesa;
        this.cliente = cliente;
    }

    public String getMesa() {
        return mesa;
    }

    public String getCliente() {
        return cliente;
    }
}
