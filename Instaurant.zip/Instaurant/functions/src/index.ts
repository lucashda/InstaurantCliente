import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
admin.initializeApp();
// // Start writing Firebase Functions
// // https://firebase.google.com/docs/functions/typescript
//
export const getPedido = functions.https.onRequest((request, response) => {
    const promise = admin.firestore().collection("Pedidos").doc("1QY5LPwy9bBxyrcKp9dT").get()
    promise.then(snapshot => {
        const data = snapshot.data()
        response.send(data)
    }).catch(error => {
        console.log(error)
        response.status(500).send(error)
    })
});
